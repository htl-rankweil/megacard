/*-------------------------------------------------------------------------*\
| Datei:        
| Version:      
| Projekt:      
| Beschreibung: 
| Schaltung:    
|               
| Autor:        
| Erstellung:   
|
| Aenderung:
\*-------------------------------------------------------------------------*/

#include <avr/io.h>

void init (void)
{
   // Initialisierungsanweisungen
}

int main (void)
{
   init ();

   while (1)
   {
      // Anweisungen der Anwendung
   }
  
   return 0;
}
