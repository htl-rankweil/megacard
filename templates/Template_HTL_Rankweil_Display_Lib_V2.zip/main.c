/*-------------------------------------------------------------------------*\
| Datei:        main.c
| Version:      1.0
| Projekt:      Einfuehrung in das Programmieren des Atmega16
| Beschreibung: Grundgeruest fuer die Anzeigebibliothek
| Schaltung:    MEGACARD V5.5
| Autor:
| Erstellung:
|
| Aenderung:
\*-------------------------------------------------------------------------*/
#include <avr/io.h>
#include <util/delay.h>
#include "display.h"

void init (void)
{
   // Grundinitialisierungen
}

int main (void)
{
   init ();        // Aufruf der Grundinitialisierungen
   display_init(); // Initialisierung der Anzeige
   
   display_string_pos (0, 4, "  HTL Rankweil");

   while (1)
   {
      // Hauptschleife
   }

   return 0;
}
